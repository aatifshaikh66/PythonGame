#####################################################################################################
'''_________________________________________________________________________________

***********************************************************************************
    File Name : game.py
***********************************************************************************
    File Type : Python file
***********************************************************************************
    Last Edit : 9/12/21
***********************************************************************************
    Version   : Version -> V0.0.0
***********************************************************************************
    Edited By : Aatif Shaikh
***********************************************************************************
    Author    : Aatif Shaikh (v16he9m2@gmail.com)
***********************************************************************************
    About file: This file is basically a template file, which discribe the
                basic rules that needs to be followed during the coding.
                By following these rules it will help you to understand
                and manage your code in a better way.
***********************************************************************************
    Licency   :
                No-Copyright (c):
                No copyrights are being imposed on these software files.
                Information shall have to be freely avaiLabel for the rapid
                development of science to benefit humanity. When the information
                is free, this is not a barrier to their progress. Therefore, I,
                Aatif Shaikh, license you the right to use, modify, copy and
                distribute this software however you desire.

                Note*
                Software and documentation are provided "as is" without warranty
                of any kind, either express or implied, including without
                limitation, any warranty of merchantability, title, non-infringement
                and fitness for a particular purpose. In no event shall, I
                (Aatif Shaikh) liable or obligated under contract, negligence,strict
                liability, contribution, breach of warranty, or other legal equitable
                theory any direct or indirect damages or expenses including but not
                limited to any incidental, special, indirect, punitive or
                consequential damages, lost profits or lost data, cost of procurement
                of substitute goods, technology, services, or any claims by third
                parties (including but not limited to any defence thereof), or
                other similar costs.
   _________________________________________________________________________'''

#####################################################################################################
'''
Short Forms:
   0: Variable      : Vr        1: Integer       : In
   2: Float/double  : Fl/Dl     3: character     : Cr
   4: String        : Sr        5: Boolean       : Bl
   6: Global        : Gl        7: Local         : Lo
   8: List          : Li        9: Mix Type      : Mx
  10: Function Name : Fn       11: Object Name:  : Ob


  Further Short forms:
  VrInLo - > VIL    VrFlLo - > VFL      VrInGl - > VIG    VrFlGl - > VFG
  VrCrLo - > VCL    VrSrLo - > VSL      VrCrGl - > VCG    VrSrGl - > VSG
  VrBlLo - > VBL                        VrBlGl - > VBG

  LiInLo - > LIL    LiFlLo - > LFL      LiInGl - > LIG    LiFlGl - > LFG
  LiCrLo - > LCL    LiSrLo - > LSL      LiCrGl - > LCG    LiSrGl - > LSG       
  LiBlLo - > LBL    LiMxLo - > LML      LiBlGl - > LBG    LiMxGl - > LMG



    1. Please follow the format given below if you want to define a Variable
       (Vr)(VariabeType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. VrInGlTemporaryVariable  /VIGTemporaryVariable 
            2. VrFlLoTemporaryVariable2 /VFLTemporaryVariable2

    1. Please follow the format given below if you want to define a List
       (Li)(ListType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. LiInLoTemporaryList    /LILTemporaryList 
            2. LiSrGlTemporaryList2   /LSLTemporaryList2


String Functions:
        1. str()    -> to convert any data into a string data
        2. strip()  -> unknown 


List Functions:
        1. count()                -> unknown
        2. insert(position,value) -> add value at specific location
        3. append(value)          -> Add value at the end of the list
        4. sort()                 -> Lowest to Highest
        5. reverse()              -> traverse from last to first


useful functions:
        1. type()                 -> it will give you the type of data



'''
#####################################################################################################


###################################################################################################
#                                               Import files                                      #
###################################################################################################
import inventory
import world
import random
import images
from time import sleep # to use delay and time functions
###################################################################################################
#                                               Global Variable                                   #
###################################################################################################

###################################################################################################
#                                               Functions                                         #
###################################################################################################
'''********************************************************************************
Function name    : FnGlBuildTheGUI
Function Argument: None
Function Return  : None
Function Info    : This Function is used to create the GUI Structure for the 
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
class Player():
    def __init__(self, VIGSelectWeapon):        

        self.PlayerWeapon  = [
        inventory.FnGlInventoryShield(), 
        inventory.FnGlInventorySward(),
        inventory.FnGlInventoryAxe()]
        
        self.PlayerStorage = [inventory.FnGlInventoryGold(15),
        self.PlayerWeapon[int(VIGSelectWeapon)],inventory.FnGlInventoryBomb()]

        self.PlayerHp = 100 # Health Points
        self.PlayerLocation_x, self.PlayerLocation_y = world.starting_position  #(0, 0)
        self.PlayerVictory = False #no victory on start up

    def flee(self, tile):
        """Moves the player randomly to an adjacent tile"""
        self.PlayerHp = self.PlayerHp  - 3         
        available_moves = tile.adjacent_moves()
        r = random.randint(0, len(available_moves) - 1)
        self.do_action(available_moves[r])

    # is_alive method
    def is_alive(self):
        return self.PlayerHp > 0   #Greater than zero value then you are still alive
 
    def print_inventory(self):
        for item in self.PlayerStorage:
            print(item, '\n')
    
    def move(self, dx, dy):
        self.PlayerLocation_x += dx
        self.PlayerLocation_y += dy
        print(world.tile_exists(self.PlayerLocation_x, self.PlayerLocation_y).intro_text())
 
    def move_north(self):
        self.move(dx=0, dy=-1)
 
    def move_south(self):
        self.move(dx=0, dy=1)
 
    def move_east(self):
        self.move(dx=1, dy=0)
 
    def move_west(self):
        self.move(dx=-1, dy=0)

    def attack(self, enemy):
        best_weapon = None
        max_dmg = 0
        counterValue = 0
        print("\n")
        for i in self.PlayerStorage:            
            if isinstance(i, inventory.FnGlInventoryWeapon):                
                counterValue = counterValue + 1                       
                printStr = "Weapon[" + str(counterValue) +"]:" + str(i.name) + "[" + str(i.value) + "]"
                print(printStr)

        while True:
            select_weapon = int(input("Please select a weapon:")) 
            
            if  select_weapon >= 1 and select_weapon <= 2:
                   if self.PlayerStorage[int(select_weapon)].value == 0 :
                        print("You can't use this weapon anymore")                
                   else:
                        break;

            else : print("Wrong Input!\nPlease Select the right Input");       
     
        
        best_weapon = self.PlayerStorage[int(select_weapon)]
        print("You use {} against {}!".format(best_weapon.name, enemy.name))
        enemy.hp -= best_weapon.damage
        self.PlayerHp = self.PlayerHp  + best_weapon.defense  -  enemy.damage 
        if (self.PlayerHp > 100 ):
            self.PlayerHp = 100
        best_weapon.value -= 1

        if not enemy.is_alive():
            print("\nYou killed {}!".format(enemy.name))
            print("\nYour Hp is {}".format(self.PlayerHp))
            self.PlayerHp = self.PlayerHp  + enemy.potion     
            images.FnGlImageBlood()            
            images.FnGlBigTextPrint("Lots of Blood!")
            sleep(3)
        else:
            print("{} HP is {}.".format(enemy.name, enemy.hp))
            print("Your Hp is {}".format(self.PlayerHp))

    def do_action(self, action, **kwargs):
         action_method = getattr(self, action.method.__name__)
         if action_method:
                action_method(**kwargs)


'''******************************************
*************End of the Function*************
******************************************'''
 