#####################################################################################################
'''_________________________________________________________________________________

***********************************************************************************
    File Name : game.py
***********************************************************************************
    File Type : Python file
***********************************************************************************
    Last Edit : 9/12/21
***********************************************************************************
    Version   : Version -> V0.0.0
***********************************************************************************
    Edited By : Aatif Shaikh
***********************************************************************************
    Author    : Aatif Shaikh (v16he9m2@gmail.com)
***********************************************************************************
    About file: This file is basically a template file, which discribe the
                basic rules that needs to be followed during the coding.
                By following these rules it will help you to understand
                and manage your code in a better way.
***********************************************************************************
    Licency   :
                No-Copyright (c):
                No copyrights are being imposed on these software files.
                Information shall have to be freely avaiLabel for the rapid
                development of science to benefit humanity. When the information
                is free, this is not a barrier to their progress. Therefore, I,
                Aatif Shaikh, license you the right to use, modify, copy and
                distribute this software however you desire.

                Note*
                Software and documentation are provided "as is" without warranty
                of any kind, either express or implied, including without
                limitation, any warranty of merchantability, title, non-infringement
                and fitness for a particular purpose. In no event shall, I
                (Aatif Shaikh) liable or obligated under contract, negligence,strict
                liability, contribution, breach of warranty, or other legal equitable
                theory any direct or indirect damages or expenses including but not
                limited to any incidental, special, indirect, punitive or
                consequential damages, lost profits or lost data, cost of procurement
                of substitute goods, technology, services, or any claims by third
                parties (including but not limited to any defence thereof), or
                other similar costs.
   _________________________________________________________________________'''

#####################################################################################################
'''
Short Forms:
   0: Variable      : Vr        1: Integer       : In
   2: Float/double  : Fl/Dl     3: character     : Cr
   4: String        : Sr        5: Boolean       : Bl
   6: Global        : Gl        7: Local         : Lo
   8: List          : Li        9: Mix Type      : Mx
  10: Function Name : Fn       11: Object Name:  : Ob


  Further Short forms:
  VrInLo - > VIL    VrFlLo - > VFL      VrInGl - > VIG    VrFlGl - > VFG
  VrCrLo - > VCL    VrSrLo - > VSL      VrCrGl - > VCG    VrSrGl - > VSG
  VrBlLo - > VBL                        VrBlGl - > VBG

  LiInLo - > LIL    LiFlLo - > LFL      LiInGl - > LIG    LiFlGl - > LFG
  LiCrLo - > LCL    LiSrLo - > LSL      LiCrGl - > LCG    LiSrGl - > LSG       
  LiBlLo - > LBL    LiMxLo - > LML      LiBlGl - > LBG    LiMxGl - > LMG



    1. Please follow the format given below if you want to define a Variable
       (Vr)(VariabeType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. VrInGlTemporaryVariable  /VIGTemporaryVariable 
            2. VrFlLoTemporaryVariable2 /VFLTemporaryVariable2

    1. Please follow the format given below if you want to define a List
       (Li)(ListType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. LiInLoTemporaryList    /LILTemporaryList 
            2. LiSrGlTemporaryList2   /LSLTemporaryList2


String Functions:
        1. str()    -> to convert any data into a string data
        2. strip()  -> unknown 


List Functions:
        1. count()                -> unknown
        2. insert(position,value) -> add value at specific location
        3. append(value)          -> Add value at the end of the list
        4. sort()                 -> Lowest to Highest
        5. reverse()              -> traverse from last to first


useful functions:
        1. type()                 -> it will give you the type of data



'''
#####################################################################################################


###################################################################################################
#                                               Import files                                      #
###################################################################################################

###################################################################################################
#                                               Global Variable                                   #
###################################################################################################
import images
import inventory
import enemies
import actions
import world
from time import sleep

###################################################################################################
#                                               Functions                                         #
###################################################################################################
'''********************************************************************************
Function name    : FnGlMessagePrint
Function Argument: string
Function Return  : None
Function Info    : This Function is used to print game messages  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
 
class MapTile:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def intro_text(self):
        raise NotImplementedError()
 
    def modify_player(self, player):
        raise NotImplementedError()

    def adjacent_moves(self):
        """Returns all move actions for adjacent tiles."""
        moves = []
        if world.tile_exists(self.x + 1, self.y):
            moves.append(actions.MoveEast())
        if world.tile_exists(self.x - 1, self.y):
            moves.append(actions.MoveWest())
        if world.tile_exists(self.x, self.y - 1):
            moves.append(actions.MoveNorth())
        if world.tile_exists(self.x, self.y + 1):
            moves.append(actions.MoveSouth())
        return moves
 
    def available_actions(self):
        """Returns all of the available actions in this room."""
        moves = self.adjacent_moves()
        moves.append(actions.ViewInventory())
        
        return moves


class EnemyRoom(MapTile):
    def __init__(self, x, y, enemy):
        self.enemy = enemy
        super().__init__(x, y)
 
    def modify_player(self, the_player):
        if self.enemy.is_alive():
            the_player.hp = the_player.hp - self.enemy.damage
            print("Enemy does {} damage. You have {} HP remaining.".format(self.enemy.damage, the_player.hp))

    def available_actions(self):
        if self.enemy.is_alive():
            return [actions.Flee(tile=self), actions.Attack(enemy=self.enemy)]
        else:
            return self.adjacent_moves()


class FnGlMap0mountain(MapTile):
    # override the intro_text method in the superclass
    def intro_text(self):
        images.FnGlImageMap1()
        images.FnGlBigTextPrint("You are on a             upper mountain!")
        return """
        """

    def modify_player(self, player):
        #Room has no action on player
        pass



class FnGlMap1mountain(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.ClGlEnemySnake())

    # override the intro_text method in the superclass
    def intro_text(self):
        images.FnGlImageMap1()
        images.FnGlBigTextPrint("You are on a             lower mountain!")
        sleep(2)               
        if self.enemy.is_alive():
            images.FnGlImageSnake()            
            images.FnGlBigTextPrint("The Amazonian Anaconda is attacking you!")
            return """
            """
        else:
             return """
            """

    def modify_player(self, player):
        #Room has no action on player
        pass




class FnGlMap2forest(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.ClGlEnemyEagle())

    # override the intro_text method in the superclass
    def intro_text(self):
        images.FnGlImageMap2()
        images.FnGlBigTextPrint("You are in the            deep Forest!")
        sleep(2)               
        if self.enemy.is_alive():
            images.FnGlImageEagle()            
            images.FnGlBigTextPrint("The Golden Eagle is attacking you!")
            return """
            """
        else:
             return """
            """
 
    def modify_player(self, player):
        #Room has no action on player
        pass


class FnGlMap3beach(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.ClGlEnemyWolf())    
    
    def intro_text(self):
        images.FnGlImageMap3()
        images.FnGlBigTextPrint("You are on the            Beach!")
        sleep(2)               
        if self.enemy.is_alive():
            images.FnGlImageWolf()            
            images.FnGlBigTextPrint("The Mackenzie wolf is attacking you!")
            return """
            """
        else:
             return """
            """
 
    def modify_player(self, player):
        #Room has no action on player
        pass


class FnGlMap4ship(MapTile):

    def intro_text(self):
        images.FnGlImageMap4()
        images.FnGlBigTextPrint("You Just Climbed on a boot!")
        return """
        """

    def modify_player(self, player):
        #Room has no action on player
        pass


class FnGlMap5ship(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.ClGlEnemyPirate())        


    def intro_text(self):
        images.FnGlImageMap5()
        images.FnGlBigTextPrint("You went inside the captain room!")
        sleep(2)               
        if self.enemy.is_alive():
            images.FnGlImagePirate()            
            images.FnGlBigTextPrint("The dead Pirate king is attacking you!")
            return """
            """
        else:
             return """
            """
 
    def modify_player(self, player):
        #Room has no action on player
        pass

class FnGlMap6finish(MapTile):
    def intro_text(self):        
        images.FnGlImageMap6()        
        images.FnGlBigTextPrint("Your ship reaches to the other side of country!")        
        sleep(2)
        images.FnGlBigTextPrint("you won the game!")                
        exit()
        return """
        """
 
    def modify_player(self, player):
        player.victory = True        


'''******************************************
*************End of the Function*************
******************************************'''

