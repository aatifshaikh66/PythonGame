#####################################################################################################
'''_________________________________________________________________________________

***********************************************************************************
    File Name : game.py
***********************************************************************************
    File Type : Python file
***********************************************************************************
    Last Edit : 9/12/21
***********************************************************************************
    Version   : Version -> V0.0.0
***********************************************************************************
    Edited By : Aatif Shaikh
***********************************************************************************
    Author    : Aatif Shaikh (v16he9m2@gmail.com)
***********************************************************************************
    About file: This file is basically a template file, which discribe the
                basic rules that needs to be followed during the coding.
                By following these rules it will help you to understand
                and manage your code in a better way.
***********************************************************************************
    Licency   :
                No-Copyright (c):
                No copyrights are being imposed on these software files.
                Information shall have to be freely avaiLabel for the rapid
                development of science to benefit humanity. When the information
                is free, this is not a barrier to their progress. Therefore, I,
                Aatif Shaikh, license you the right to use, modify, copy and
                distribute this software however you desire.

                Note*
                Software and documentation are provided "as is" without warranty
                of any kind, either express or implied, including without
                limitation, any warranty of merchantability, title, non-infringement
                and fitness for a particular purpose. In no event shall, I
                (Aatif Shaikh) liable or obligated under contract, negligence,strict
                liability, contribution, breach of warranty, or other legal equitable
                theory any direct or indirect damages or expenses including but not
                limited to any incidental, special, indirect, punitive or
                consequential damages, lost profits or lost data, cost of procurement
                of substitute goods, technology, services, or any claims by third
                parties (including but not limited to any defence thereof), or
                other similar costs.
   _________________________________________________________________________'''

#####################################################################################################
'''
Short Forms:
   0: Variable      : Vr        1: Integer       : In
   2: Float/double  : Fl/Dl     3: character     : Cr
   4: String        : Sr        5: Boolean       : Bl
   6: Global        : Gl        7: Local         : Lo
   8: List          : Li        9: Mix Type      : Mx
  10: Function Name : Fn       11: Object Name:  : Ob


  Further Short forms:
  VrInLo - > VIL    VrFlLo - > VFL      VrInGl - > VIG    VrFlGl - > VFG
  VrCrLo - > VCL    VrSrLo - > VSL      VrCrGl - > VCG    VrSrGl - > VSG
  VrBlLo - > VBL                        VrBlGl - > VBG

  LiInLo - > LIL    LiFlLo - > LFL      LiInGl - > LIG    LiFlGl - > LFG
  LiCrLo - > LCL    LiSrLo - > LSL      LiCrGl - > LCG    LiSrGl - > LSG       
  LiBlLo - > LBL    LiMxLo - > LML      LiBlGl - > LBG    LiMxGl - > LMG



    1. Please follow the format given below if you want to define a Variable
       (Vr)(VariabeType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. VrInGlTemporaryVariable  /VIGTemporaryVariable 
            2. VrFlLoTemporaryVariable2 /VFLTemporaryVariable2

    1. Please follow the format given below if you want to define a List
       (Li)(ListType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. LiInLoTemporaryList    /LILTemporaryList 
            2. LiSrGlTemporaryList2   /LSLTemporaryList2


String Functions:
        1. str()    -> to convert any data into a string data
        2. strip()  -> unknown 


List Functions:
        1. count()                -> unknown
        2. insert(position,value) -> add value at specific location
        3. append(value)          -> Add value at the end of the list
        4. sort()                 -> Lowest to Highest
        5. reverse()              -> traverse from last to first


useful functions:
        1. type()                 -> it will give you the type of data



'''
#####################################################################################################


###################################################################################################
#                                               Import files                                      #
###################################################################################################
import os  # to use the system commands
from time import sleep  # to use delay and time functions
import pyfiglet

###################################################################################################
#                                               Global Variable                                   #
###################################################################################################
#game master
VSGGameMaster = "image/gamemaster.txt"
VSGMaleChar  = "image/male.txt"
VSGFemaleChar = "image/female.txt"

#maps
VSGMountain1  = "image/mountain1.txt"
VSGForest1    = "image/forest1.txt"
VSGRiver1     = "image/river1.txt"
VSGShip1      = "image/ship1.txt"
VSGShip2      = "image/room1.txt"
VSGland1      = "image/land1.txt"


#wepons
VSGWeapon     = "image/weapon.txt"
VSGSward      = "image/sward.txt"
VSGBomb       = "image/bomb.txt"
VSGShield     = "image/shield.txt"
VSGAxe        = "image/axe.txt"

#enemy
VSGWolf       = "image/wolf.txt"
VSGSnake      = "image/snake.txt"
VSGEagle      = "image/eagle.txt"
VSGPirate     = "image/pirate.txt"

#story
VSGAirplane     = "image/airplane.txt"
VSGWindow       = "image/window.txt"
VSGTornado      = "image/tornado.txt"
VSGCrash        = "image/crash.txt"
VSGMagic        = "image/magic.txt"
VSGSleep        = "image/sleep.txt"


#dead
VSGDeadCharacter = "/home/mshaikh/Desktop/AP/image/dead.txt"
VSGDeadEnemy     = "/home/mshaikh/Desktop/AP/image/blood.txt"



###################################################################################################
#                                               Functions                                         #
###################################################################################################
'''********************************************************************************
Function name    : FnGlImagePrint
Function Argument: string
Function Return  : None
Function Info    : This Function is used to print the images 
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImagePrint(VSLFileName):
    os.system("clear")
    with open(VSLFileName, "r") as IMAGEPRINT:
         for printImage in IMAGEPRINT:
             print(printImage, end="")
    print("")
'''******************************************
*************End of the Function*************
******************************************'''


'''********************************************************************************
Function name    : FnGlSelectBlock
Function Argument: None
Function Return  : None
Function Info    : This Function is used to update the GUI  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlBigTextPrint(VSLPrintString):
    VSLPrintString = pyfiglet.figlet_format(VSLPrintString)
    print(VSLPrintString)    

'''******************************************
*************End of the Function*************
******************************************'''

'''********************************************************************************
Function name    : Story
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game guide master 
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageStoryImage1():
        FnGlImagePrint(VSGAirplane);

def FnGlImageStoryImage2():
        FnGlImagePrint(VSGWindow);

def FnGlImageStoryImage3():
        FnGlImagePrint(VSGTornado);

def FnGlImageStoryImage4():
        FnGlImagePrint(VSGCrash);

def FnGlImageStoryImage5():
        FnGlImagePrint(VSGMagic);

def FnGlImageStoryImage6():
        FnGlImagePrint(VSGSleep);


'''******************************************
*************End of the Function*************
******************************************'''


'''********************************************************************************
Function name    : Story
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game guide master 
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageBlood():
        FnGlImagePrint(VSGDeadEnemy);

def FnGlImageDeadChacter():
        FnGlImagePrint(VSGDeadCharacter);

'''******************************************
*************End of the Function*************
******************************************'''        

'''********************************************************************************
Function name    : All character together
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game guide master 
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageGameGuide():
    FnGlImagePrint(VSGGameMaster)

def FnGlImageMaleChar():
    FnGlImagePrint(VSGMaleChar)

def FnGlImageFemaleChar():
    FnGlImagePrint(VSGFemaleChar)



'''******************************************
*************End of the Function*************
******************************************'''
'''********************************************************************************
Function name    : FnGlImageMap1
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game's first map
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageMap1():
    FnGlImagePrint(VSGMountain1)

def FnGlImageMap2():
    FnGlImagePrint(VSGForest1)

def FnGlImageMap3():
    FnGlImagePrint(VSGRiver1)

def FnGlImageMap4():
    FnGlImagePrint(VSGShip1)

def FnGlImageMap5():
    FnGlImagePrint(VSGShip2)

def FnGlImageMap6():
    FnGlImagePrint(VSGland1)


'''******************************************
*************End of the Function*************
******************************************'''
'''********************************************************************************
Function name    : All wepons together
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game's first map
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageWeapon():
    FnGlImagePrint(VSGWeapon)

def FnGlImageSward():
    FnGlImagePrint(VSGSward)

def FnGlImageAxe():
    FnGlImagePrint(VSGAxe)

def FnGlImageShield():
    FnGlImagePrint(VSGShield)

def FnGlImageBomb():
    FnGlImagePrint(VSGBomb)

'''******************************************
*************End of the Function*************
******************************************'''

'''********************************************************************************
Function name    : All enemies together
Function Argument: None
Function Return  : None
Function Info    : This Function is used to print game's first map
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlImageWolf( ):
    FnGlImagePrint(VSGWolf)

def FnGlImageEagle( ):
    FnGlImagePrint(VSGEagle)

def FnGlImageSnake( ):
    FnGlImagePrint(VSGSnake)

def FnGlImagePirate( ):
    FnGlImagePrint(VSGPirate)


'''******************************************
*************End of the Function*************
******************************************'''