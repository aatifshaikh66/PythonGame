#####################################################################################################
'''_________________________________________________________________________________

***********************************************************************************
    File Name : game.py
***********************************************************************************
    File Type : Python file
***********************************************************************************
    Last Edit : 9/12/21
***********************************************************************************
    Version   : Version -> V0.0.0
***********************************************************************************
    Edited By : Aatif Shaikh
***********************************************************************************
    Author    : Aatif Shaikh (v16he9m2@gmail.com)
***********************************************************************************
    About file: This file is basically a template file, which discribe the
                basic rules that needs to be followed during the coding.
                By following these rules it will help you to understand
                and manage your code in a better way.
***********************************************************************************
    Licency   :
                No-Copyright (c):
                No copyrights are being imposed on these software files.
                Information shall have to be freely avaiLabel for the rapid
                development of science to benefit humanity. When the information
                is free, this is not a barrier to their progress. Therefore, I,
                Aatif Shaikh, license you the right to use, modify, copy and
                distribute this software however you desire.

                Note*
                Software and documentation are provided "as is" without warranty
                of any kind, either express or implied, including without
                limitation, any warranty of merchantability, title, non-infringement
                and fitness for a particular purpose. In no event shall, I
                (Aatif Shaikh) liable or obligated under contract, negligence,strict
                liability, contribution, breach of warranty, or other legal equitable
                theory any direct or indirect damages or expenses including but not
                limited to any incidental, special, indirect, punitive or
                consequential damages, lost profits or lost data, cost of procurement
                of substitute goods, technology, services, or any claims by third
                parties (including but not limited to any defence thereof), or
                other similar costs.
   _________________________________________________________________________'''

#####################################################################################################
'''
Short Forms:
   0: Variable      : Vr        1: Integer       : In
   2: Float/double  : Fl/Dl     3: character     : Cr
   4: String        : Sr        5: Boolean       : Bl
   6: Global        : Gl        7: Local         : Lo
   8: List          : Li        9: Mix Type      : Mx
  10: Function Name : Fn       11: Object Name:  : Ob


  Further Short forms:
  VrInLo - > VIL    VrFlLo - > VFL      VrInGl - > VIG    VrFlGl - > VFG
  VrCrLo - > VCL    VrSrLo - > VSL      VrCrGl - > VCG    VrSrGl - > VSG
  VrBlLo - > VBL                        VrBlGl - > VBG

  LiInLo - > LIL    LiFlLo - > LFL      LiInGl - > LIG    LiFlGl - > LFG
  LiCrLo - > LCL    LiSrLo - > LSL      LiCrGl - > LCG    LiSrGl - > LSG       
  LiBlLo - > LBL    LiMxLo - > LML      LiBlGl - > LBG    LiMxGl - > LMG



    1. Please follow the format given below if you want to define a Variable
       (Vr)(VariabeType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. VrInGlTemporaryVariable  /VIGTemporaryVariable 
            2. VrFlLoTemporaryVariable2 /VFLTemporaryVariable2

    1. Please follow the format given below if you want to define a List
       (Li)(ListType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. LiInLoTemporaryList    /LILTemporaryList 
            2. LiSrGlTemporaryList2   /LSLTemporaryList2


String Functions:
        1. str()    -> to convert any data into a string data
        2. strip()  -> unknown 
 
 
List Functions:
        1. count()                -> unknown
        2. insert(position,value) -> add value at specific location
        3. append(value)          -> Add value at the end of the list
        4. sort()                 -> Lowest to Highest
        5. reverse()              -> traverse from last to first
 
 
useful functions:
        1. type()                 -> it will give you the type of data
 
 
 
'''
#####################################################################################################


###################################################################################################
#                                               Import files                                      #
###################################################################################################

###################################################################################################
#                                               Global Variable                                   #
###################################################################################################

###################################################################################################
#                                               Functions                                         #
###################################################################################################
'''********************************************************************************
Function name    : FnGlMessagePrint
Function Argument: string
Function Return  : None
Function Info    : This Function is used to print game messages  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
class ClGlEnemy:
    def __init__(self, name, hp, damage, fleedamage, potion):
        self.name       = name
        self.hp         = hp
        self.damage     = damage
        self.fleedamage = fleedamage 
        self.potion     = potion


    def is_alive(self):
        return self.hp > 0


class ClGlEnemySnake(ClGlEnemy):
    def __init__(self):
        super().__init__(name="Amazonian Anaconda", hp=20, damage=5, fleedamage= 2, potion= -5)

class ClGlEnemyEagle(ClGlEnemy):
    def __init__(self):
        super().__init__(name="Golden Eagle", hp=15, damage=7, fleedamage= 3, potion = 2)

class ClGlEnemyWolf(ClGlEnemy):
    def __init__(self):
        super().__init__(name="Mackenzie Wold", hp=30, damage=14, fleedamage= 7, potion= 5)

class ClGlEnemyPirate(ClGlEnemy):
    def __init__(self):
        super().__init__(name="Flying Dutchman", hp=40, damage=20, fleedamage= 7, potion= 5)


'''******************************************
************end of the Function************
******************************************'''

