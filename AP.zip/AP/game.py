#####################################################################################################
'''_________________________________________________________________________________

***********************************************************************************
    File Name : game.py
***********************************************************************************
    File Type : Python file
***********************************************************************************
    Last Edit : 9/12/21
***********************************************************************************
    Version   : Version -> V0.0.0
***********************************************************************************
    Edited By : Aatif Shaikh
***********************************************************************************
    Author    : Aatif Shaikh (v16he9m2@gmail.com)
***********************************************************************************
    About file: This file is basically a template file, which discribe the
                basic rules that needs to be followed during the coding.
                By following these rules it will help you to understand
                and manage your code in a better way.
***********************************************************************************
    Licency   :
                No-Copyright (c):
                No copyrights are being imposed on these software files.
                Information shall have to be freely avaiLabel for the rapid
                development of science to benefit humanity. When the information
                is free, this is not a barrier to their progress. Therefore, I,
                Aatif Shaikh, license you the right to use, modify, copy and
                distribute this software however you desire.

                Note*
                Software and documentation are provided "as is" without warranty
                of any kind, either express or implied, including without
                limitation, any warranty of merchantability, title, non-infringement
                and fitness for a particular purpose. In no event shall, I
                (Aatif Shaikh) liable or obligated under contract, negligence,strict
                liability, contribution, breach of warranty, or other legal equitable
                theory any direct or indirect damages or expenses including but not
                limited to any incidental, special, indirect, punitive or
                consequential damages, lost profits or lost data, cost of procurement
                of substitute goods, technology, services, or any claims by third
                parties (including but not limited to any defence thereof), or
                other similar costs.
   _________________________________________________________________________'''

#####################################################################################################
'''
Short Forms:
   0: Variable      : Vr        1: Integer       : In
   2: Float/double  : Fl/Dl     3: character     : Cr
   4: String        : Sr        5: Boolean       : Bl
   6: Global        : Gl        7: Local         : Lo
   8: List          : Li        9: Mix Type      : Mx
  10: Function Name : Fn       11: Object Name:  : Ob


  Further Short forms:
  VrInLo - > VIL    VrFlLo - > VFL      VrInGl - > VIG    VrFlGl - > VFG
  VrCrLo - > VCL    VrSrLo - > VSL      VrCrGl - > VCG    VrSrGl - > VSG
  VrBlLo - > VBL                        VrBlGl - > VBG

  LiInLo - > LIL    LiFlLo - > LFL      LiInGl - > LIG    LiFlGl - > LFG
  LiCrLo - > LCL    LiSrLo - > LSL      LiCrGl - > LCG    LiSrGl - > LSG       
  LiBlLo - > LBL    LiMxLo - > LML      LiBlGl - > LBG    LiMxGl - > LMG



    1. Please follow the format given below if you want to define a Variable
       (Vr)(VariabeType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. VrInGlTemporaryVariable  /VIGTemporaryVariable 
            2. VrFlLoTemporaryVariable2 /VFLTemporaryVariable2

    1. Please follow the format given below if you want to define a List
       (Li)(ListType)(Global/local)(VariableDefinition1)(VariableDefinition2)..
       Example:
            1. LiInLoTemporaryList    /LILTemporaryList 
            2. LiSrGlTemporaryList2   /LSLTemporaryList2


String Functions:
        1. str()    -> to convert any data into a string data
        2. strip()  -> unknown 


List Functions:
        1. count()                -> unknown
        2. insert(position,value) -> add value at specific location
        3. append(value)          -> Add value at the end of the list
        4. sort()                 -> Lowest to Highest
        5. reverse()              -> traverse from last to first


useful functions:
        1. type()                 -> it will give you the type of data



'''
#####################################################################################################


###################################################################################################
#                                               Import files                                      #
###################################################################################################
from time import sleep # to use delay and time functions
import os  		# to use the system commands
import datetime  	# to get the local date and time
import locale  	#
import time  		# to access and use local timers
import threading	# to use multi-threading process
import socket  	# to use socket applications
import select  	#
import sys  		#
import hashlib  	# to use for hasing
# import urllib        #
import urllib.parse  	# to process the web related functionality
import urllib.request  # to process the web related functionality
import json  		#
import pprint  	#
import tkinter as tk
from tkinter import *
from tkinter import messagebox
import random
from playsound import playsound
import pyfiglet

#user defined modules
import images
from images import FnGlBigTextPrint
import world
import inventory
from player import Player
import player
import map

###################################################################################################
#                                               Global Variable                                   #
###################################################################################################


###################################################################################################
#                                               Functions                                         #
###################################################################################################

'''********************************************************************************
Function name    : FnGlSelectBlock
Function Argument: None
Function Return  : None
Function Info    : This Function is used to update the GUI  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlStartStory( ):
    VILSleepTime = 3
    os.system("clear"); FnGlBigTextPrint("          Welcome"); sleep(VILSleepTime)
    os.system("clear"); FnGlBigTextPrint("this is a story mode game"); sleep(VILSleepTime)           
    images.FnGlImageStoryImage1( )
    FnGlBigTextPrint("You are travelling           in an airplane"); 
    #playsound('/home/mshaikh/Desktop/AP/sound/airplane1.wav');
    sleep(VILSleepTime)

    images.FnGlImageStoryImage2( )
    FnGlBigTextPrint("You look in the                              window"); sleep(VILSleepTime)
    os.system("clear"); FnGlBigTextPrint("You notice a                               Tornado!"); sleep(VILSleepTime)
    images.FnGlImageStoryImage3( );  sleep(VILSleepTime)    
    os.system("clear"); FnGlBigTextPrint("It's approaching          your airplane!"); sleep(VILSleepTime)
    os.system("clear"); FnGlBigTextPrint("It cought you!"); sleep(VILSleepTime) 
    images.FnGlImageStoryImage4( );  sleep(VILSleepTime)
    os.system("clear"); FnGlBigTextPrint("    you are crhashing!"); sleep(VILSleepTime) 
    images.FnGlImageStoryImage5( );  sleep(VILSleepTime)
    FnGlBigTextPrint("              something Magical Happend!"); sleep(VILSleepTime)        
    images.FnGlImageStoryImage6( );  sleep(VILSleepTime)
    FnGlBigTextPrint("Somehow you                   survived!"); sleep(VILSleepTime)        
    os.system("clear"); FnGlBigTextPrint("           You see someome               approcing you!"); sleep(VILSleepTime) 

'''******************************************
*************End of the Function*************
******************************************'''

'''********************************************************************************
Function name    : FnGlSelectBlock
Function Argument: None
Function Return  : None
Function Info    : This Function is used to update the GUI  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlStartGameMaster( ):
    VILSleepTime = 2
    images.FnGlImageGameGuide();
    FnGlBigTextPrint("Welcome to the                  Zambaas!"); sleep(VILSleepTime)  
    os.system("clear"); 

    images.FnGlImageGameGuide();
    FnGlBigTextPrint("         I'm The                        Game Master!"); sleep(VILSleepTime)  
    os.system("clear"); 

    images.FnGlImageGameGuide();
    FnGlBigTextPrint("Please Select                     a character!");
    FnGlBigTextPrint("1-Male!");    
    FnGlBigTextPrint("2-Female!");    

    VIGSelectCharacter = 0
    while True:
            VIGSelectCharacter = int(input("Select[1-2]:"));
            if   VIGSelectCharacter == 1 :
                 images.FnGlImageMaleChar();
                 FnGlBigTextPrint("You selected a male charachter");                                
                 sleep(VILSleepTime) 
                 break;
            elif VIGSelectCharacter == 2 :
                 images.FnGlImageFemaleChar();
                 FnGlBigTextPrint("You selected a female charachter");                                
                 sleep(VILSleepTime) 
                 break;
            else : 
               print("Wrong Input!\nPlease Select the right Input");       

    images.FnGlImageGameGuide();
    FnGlBigTextPrint("Please Select                     a Weapon!"); sleep(VILSleepTime)  
    images.FnGlImageWeapon(); sleep(VILSleepTime);

    VLLWeaponSelect = [inventory.FnGlInventoryShield(),inventory.FnGlInventorySward(),inventory.FnGlInventoryAxe()]    
    for x in range(3): 
        print("=====\n[{}]{}\n=====\n{}\nValue: {}\nDamage: {}\nDefense: {}\n\n".format(x +1, VLLWeaponSelect[x].name,
         VLLWeaponSelect[x].description, VLLWeaponSelect[x].value, VLLWeaponSelect[x].damage, VLLWeaponSelect[x].defense))    

    VIGSelectWeapon = 0
    while True:
            VIGSelectWeapon = int(input("Select[1-3]:"))
            if VIGSelectWeapon == 1 or VIGSelectWeapon == 2 or VIGSelectWeapon == 3 :
                   if   VIGSelectWeapon == 1 :
                        images.FnGlImageShield();
                        FnGlBigTextPrint("You selected the SHIELD");                           
                   elif VIGSelectWeapon == 2 : 
                        images.FnGlImageSward();
                        FnGlBigTextPrint("You selected the SWARD");                        
                   elif VIGSelectWeapon == 3 : 
                        images.FnGlImageAxe();
                        FnGlBigTextPrint("You selected the AXE");                                                 

                   sleep(VILSleepTime) 
                   break;
            else : 
               print("Wrong Input!\nPlease Select the right Input");       

    images.FnGlImageGameGuide();
    FnGlBigTextPrint("Your Adventure is now begain!"); sleep(VILSleepTime)  
    sleep(VILSleepTime);

    return ( VIGSelectWeapon -1 );


'''******************************************
*************End of the Function*************
******************************************'''

'''********************************************************************************
Function name    : FnGlSelectBlock
Function Argument: None
Function Return  : None
Function Info    : This Function is used to update the GUI  
********************************************************************************'''
'''******************************************
************Start of the Function************
******************************************'''
def FnGlStartTheGame():
            
    world.load_tiles( ) 
    VIGSelectWeapon =FnGlStartGameMaster()
    player = Player(VIGSelectWeapon)       
    #These lines load the starting room and display the text
    room = world.tile_exists(player.PlayerLocation_x, player.PlayerLocation_y)
    print(room.intro_text())
    while player.is_alive() and not player.PlayerVictory:
        room = world.tile_exists(player.PlayerLocation_x, player.PlayerLocation_y)
        room.modify_player(player)
        # Check again since the room could have changed the player's state
        if player.is_alive() and not player.PlayerVictory:
            print("Choose an action:\n")
            available_actions = room.available_actions()
            for action in available_actions:
                print(action)
            action_input = input('Action: ')
            for action in available_actions:
                if action_input == action.hotkey:
                    player.do_action(action, **action.kwargs)
                    break

    if player.is_alive() > 0 :
            images.FnGlImageDeadChacter()
            images.FnGlBigTextPrint("you are dead!")
            exit()



'''******************************************
*************End of the Function*************
******************************************'''



###################################################################################################
#                                               Start of the code                                 #
###################################################################################################
if __name__ == "__main__":
    '''*******initial story*******'''
    FnGlStartStory()
    FnGlStartTheGame()
    
